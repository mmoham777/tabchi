# [Tabchi | v.1](https://telegram.me/etehad_arazel)

آخرین ورژن تبچی تبچی رباتی بر پایه ورژن جدید سی ال آی با این ربات به تبلیغات در تلگرام بپردازید بدون تبلیغات ای تیم (ستاره یادتون نره)تبچی بدون دیلیت شدن


تبچی خودت رو بساز ;)


* * *

### دستورات


| [#!/]help | راهنما  |


* * *

# نصب

```sh
git clone https://github.com/persiancyber/persianteam
cd persianteam
chmod +x bot
./bot install
# and send [y] to finish install
```
* * *
## ساخت ربات
```
./bot create
./bot 1
وارد کردن ایدی عددی سودو#
وارد کردن شماره ربات#
```
## ساخت ربات های بیش تر

```sh
cd persianteam
./bot create
./bot number of bot >> شماره رباتی که به شما میدهد
وارد کردن ایدی عددی سودو#
وارد کردن شماره ربات#
```
* * *
## اتولاچ
```sh
cd persianteam
./bot autolaunch
تمام ربات ها راه اندازی میشوند بدون خاموشی#
```
***
### اموزش ها

[اموزش کامل نصب](https://telegram.me/etehad_arazel)

### Developers
[persiancyber1](https://telegram.me/persiancyber1)
### channel
[arazelteam](https://telegram.me/etehad_arazel)
